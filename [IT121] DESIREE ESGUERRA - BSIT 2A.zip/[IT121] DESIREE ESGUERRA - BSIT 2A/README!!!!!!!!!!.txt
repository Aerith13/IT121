-------ASSIGNMENT-----------
Lab Activity PHP + Database

submitted by:
DESIREE ESGUERRA - BSIT - 2A

----------------------------------
