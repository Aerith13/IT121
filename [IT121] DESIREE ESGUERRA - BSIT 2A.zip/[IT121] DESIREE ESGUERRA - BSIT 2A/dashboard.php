<?php
session_start();

// Redirect user to login page if they're not logged in
if (!isset($_SESSION["username"])) {
    header("Location: login.php");
    exit();
}

// Connect to database
$host = "localhost";
$user = "root";
$password = "";
$database = "mydb";
$conn = mysqli_connect($host, $user, $password, $database);

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Fetch user's details from database
$username = $_SESSION["username"];
$sql = "SELECT full_name, nickname, permanent_address, current_address, username, email, gender, nationality, phone_number, civil_status, parents FROM users WHERE username='$username'";
$result = mysqli_query($conn, $sql);

if (!$result) {
    die("Query failed: " . mysqli_error($conn));
}

// Get user's full name and nickname
$row = mysqli_fetch_assoc($result);
$fullName = $row["full_name"];
$nickname = $row["nickname"];
$permanent_address = $row["permanent_address"];
$current_address = $row["current_address"];
$username = $row["username"];
$email = $row["email"];
$gender = $row["gender"];
$nationality = $row["nationality"];
$phone_number = $row["phone_number"];
$civil_status = $row["civil_status"];
$parents = $row["parents"];
// Close database connection
mysqli_close($conn);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Dashboard</title>
    <style>
    .container {
        margin: auto;
        width: 60%;
        padding: 20px;
        border: 2px solid #dddddd;
        background-color: rgba(255, 255, 255, 0.8);
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
    }

    .logout {
        position: absolute;
        top: 20px;
        right: 20px;
    }

    body {
        background: linear-gradient(to bottom right, #ee95ab, #813e59);
        font-family: 'Courier New', Courier, monospace;
        font-size: 16px;
        line-height: 1.6;
    }
    
    h1 {
        font-size: 24px;
        font-weight: bold;
        margin-bottom: 16px;
    }
    
    p {
        margin-bottom: 8px;
    }
    
    form {
        margin-top: 16px;
    }
    
    input[type="submit"] {
        background-color: #4CAF50;
        border: none;
        color: white;
        padding: 12px 20px;
        text-align: center;
        text-decoration: none;
        display: inline-block;
        font-size: 16px;
        border-radius: 4px;
        cursor: pointer;
    }
    
    input[type="submit"]:hover {
        background-color: #3e8e41;
    }


    </style>
</head>
<body>
    <center>
    <div class="container">
    <p>Welcome, <?php echo $fullName; ?>!</p>
    <p>It's great to have you here.</p><br>
    <p>Your nickname, <b><?php echo $nickname; ?></b>, adds a personal touch to your profile.</p>
    <p>Your permanent address at <b><?php echo $permanent_address; ?></b> and currently resides at <b><?php echo $current_address; ?></b> show us that you're a traveler at heart.</p><br>
    <p>Your username, <b><?php echo $username; ?></b>, and email, <b><?php echo $email; ?></b>,</p>
    <p> are unique to you and give you access to our amazing community.</p><br>
    <p>We are proud to have you as a <b><?php echo $gender; ?></b> of <b><?php echo $nationality; ?></b> descent.</p>
    <p>We can also reach you at <b><?php echo $phone_number; ?></b> in case we need to.</p>
    <p>You are <b><?php echo $civil_status; ?></b>, and we hope to help you make meaningful connections here.</p>
    <p> We can't wait to see what you'll bring to the community, </p>
    <p>especially with the support of your parents <b><?php echo $parents; ?></b>.</p>
    </div>
    </center>
    
    <form class="logout" action="logout.php" method="post">
            <input type="submit" value="Logout">
        </form>
</body>
</html>
