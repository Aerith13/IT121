<?php
// Start session
session_start();

// Unset session variables and destroy session
session_unset();
session_destroy();

// Redirect to homepage
header("Location: index.php");
exit;
?>
