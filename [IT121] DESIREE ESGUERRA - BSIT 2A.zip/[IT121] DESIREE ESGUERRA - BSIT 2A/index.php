<?php
include('connection.php');
?>

<!DOCTYPE html>
<html>
<head>
    <title>My Website</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <div class="box">
            <h1><center>🍒 Welcome 🍒</center></h1>
            <h2><center>website by: <b>Desiree Esguerra</b></center></h2><br>
            <div class="buttons">
                <center>
                <a href="register.php">Register</a>
                <a href="login.php">Login</a>
                </center>
            </div>
        </div>
    </div>
</body>
</html>

