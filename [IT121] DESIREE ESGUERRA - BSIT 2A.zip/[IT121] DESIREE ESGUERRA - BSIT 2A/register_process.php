<?php
// Establish database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "mydb";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Retrieve form data
$full_name = $_POST["full_name"];
$permanent_address = $_POST["permanent_address"];
$current_address = $_POST["current_address"];
$username = $_POST["username"];
$password = password_hash($_POST["password"], PASSWORD_DEFAULT); // Hash password
$email = $_POST["email"];
$nickname = $_POST["nickname"];
$gender = $_POST["gender"];
$nationality = $_POST["nationality"];
$phone_number = $_POST["phone_number"];
$civil_status = $_POST["civil_status"];
$parents = $_POST["parents"];

// Insert data into database
$sql = "INSERT INTO users (full_name, permanent_address, current_address, username, password, email, nickname, gender, nationality, phone_number, civil_status, parents)
VALUES ('$full_name', '$permanent_address', '$current_address', '$username', '$password', '$email', '$nickname', '$gender', '$nationality', '$phone_number', '$civil_status', '$parents')";

if ($conn->query($sql) === TRUE) {
echo "Registration successful";
} else {
echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>