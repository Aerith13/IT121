<?php
include('connection.php');
if ($registration_successful) {
    header("Location: index.php");
    exit();
}
?>


<!DOCTYPE html>
<html>
<head>
    <title>Register</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
    <div class="box">
    <h1><center>Register</center></h1>
    <form method="post" action="register_process.php">
        <label>Full Name</label>
        <input type="text" name="full_name" required><br>

        <label>Permanent Address</label>
        <input type="text" name="permanent_address" required><br>

        <label>Current Address</label>
        <input type="text" name="current_address" required><br>

        <label>Username</label>
        <input type="text" name="username" required><br>

        <label>Password</label>
        <input type="password" name="password" required><br>

        <label for="email" class="form-label">Email:</label>
        <input type="email" name="email" id="email" class="form-input" required><br><br>


        <label>Nickname</label>
        <input type="text" name="nickname" required><br>

        <label>Gender: </label>
            <div class="radio-container">
            <input type="radio" name="gender" value="Male" id="male" required>
            <label for="male">Male</label>
            <input type="radio" name="gender" value="Female" id="female" required>
            <label for="female">Female</label>
            </div><br>
            
        <label>Nationality</label>
        <input type="text" name="nationality" required><br>

        <label>Phone Number</label>
        <input type="text" name="phone_number" required><br>

        <label>Civil Status</label>
        <select name="civil_status" required>
            <option value="Single">Single</option>
            <option value="Married">Married</option>
            <option value="Divorced">Divorced</option>
            <option value="Widowed">Widowed</option>
        </select><br>

        <label>Parents</label>
        <input type="text" name="parents" required><br>

        <input type="submit" value="Register" class="login-btn">
    </form>
    </div>
</div>
</body>
</html>
