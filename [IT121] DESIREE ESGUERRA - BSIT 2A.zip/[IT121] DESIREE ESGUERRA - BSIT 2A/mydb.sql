CREATE DATABASE mydb;
USE mydb;

CREATE TABLE users (
  id INT(11) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  full_name VARCHAR(255) NOT NULL,
  permanent_address VARCHAR(255) NOT NULL,
  current_address VARCHAR(255) NOT NULL,
  username VARCHAR(50) NOT NULL,
  password VARCHAR(255) NOT NULL,
  email VARCHAR(100) NOT NULL,
  nickname VARCHAR(50) NOT NULL,
  gender VARCHAR(10) NOT NULL,
  nationality VARCHAR(50) NOT NULL,
  phone_number VARCHAR(20) NOT NULL,
  civil_status VARCHAR(20) NOT NULL,
  parents VARCHAR(255) NOT NULL
);

CREATE TABLE sessions (
  id INT(11) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(50) NOT NULL,
  token VARCHAR(255) NOT NULL,
  expiry DATETIME NOT NULL
);


--INSERT INTO users (full_name, permanent_address, current_address, username, password, email, nickname, gender, nationality, phone_number, civil_status, parents)
--VALUES ('Admin User', '123 Main St', '456 Elm St', 'admin', '$2y$10$5m5lC2SSAzqw19lBpxDwCO87Jb1EgWeNVpWhEBN.jhxZ9JjhN0.T2', 'admin@example.com', 'Admin', 'Male', 'American', '1234567890', 'Single', 'John and Jane Doe');
